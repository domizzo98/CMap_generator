# Modules to be imported
import pydot, requests, re
import pickle, graphviz, nltk
import pandas as pd
import numpy as np
from nltk.tokenize import sent_tokenize
from nltk.tokenize import word_tokenize
from unidecode import unidecode
pd.options.mode.chained_assignment = None

print("All imported")